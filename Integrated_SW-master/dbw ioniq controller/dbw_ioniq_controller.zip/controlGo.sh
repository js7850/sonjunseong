cd ~/startup/dbw_ioniq_controller
python dbw_controller.py
