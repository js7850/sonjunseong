### 종속성
  1. sudo apt install python3-pyqt5.qtmultimedia
  2. sudo apt-get install libqt5multimedia5-plugins
