// subscribe point cloud from /velodyne topics

#include <iostream>

#include <ros/ros.h>
#include <cmath>
#include <sensor_msgs/PointCloud2.h>
#include <visualization_msgs/MarkerArray.h>
#include <visualization_msgs/Marker.h>
#include <std_msgs/Int16MultiArray.h>

#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>

#include <vector>
#define _USE_MATH_DEFINES

#include <opencv2/opencv.hpp>

#include <algorithm>

#include <time.h>

#include <image_transport/image_transport.h>
#include <opencv/cvwimage.h>
#include <opencv/highgui.h>
#include <cv_bridge/cv_bridge.h>

#include <tracking_msg/TrackingObjectArray.h>
#include <tracking_msg/TrackingObject.h>

#include "iou.h"

using namespace cv ;
using namespace std ;

ros::Publisher pub;

typedef pcl::PointXYZ	PointXYZ;
pcl::PointCloud<PointXYZ> global_cloud;
std_msgs::Int16MultiArray yolo_data;
std_msgs::Int16MultiArray car_data;
tracking_msg::TrackingObjectArray lidar_data;

//--------------LIDAR PARAMETER----------------
float min_fov = -15;
float max_fov = 15;
float hres = 0.06414;
float vres =0.076018 ;
int y_fudge = 90 ;


int v_fov_total = -min_fov+max_fov ;

float pi = M_PI;

float v_res_rad = vres * (pi/180) ;
float h_res_rad = hres * (pi/180) ;

//-------------IMAGE parameter-----------------

float x_min = - 360.0/hres/2 ;
float x_max = 360.0/hres ;
float y_min = min_fov / vres;
float y_max = v_fov_total / vres ;

int height = 300 ;
int width = 3600 ;

cv_bridge::CvImagePtr cv_ptr;

int h = 720;
int w = 1280;



//-------------about yolo--------------
int yolo_bbox_n;
int car_data_n;

std::vector<std::string> COCO_CLASSES_LIST = {"person" , "bicycle" , "car" , "motorbike" , "aeroplane" , "bus" , "train" , "truck" , "boat" , "traffic light" , "fire hydrant" , "stop sign" , "parking meter" , "bench" , "bird" , "cat" , "dog" , "horse" , "sheep" , "cow" , "elephant" , "bear" , "zebra" , "giraffe" , "backpack" , "umbrella" , "handbag" , "tie" , "suitcase" , "frisbee" , "skis" , "snowboard" , "sports ball" , "kite" , "baseball bat" , "baseball glove" , "skateboard" , "surfboard" , "tennis racket" , "bottle" , "wine glass" , "cup" , "fork" , "knife" , "spoon" , "bowl" , "banana" , "apple" , "sandwich" , "orange" , "broccoli" , "carrot" , "hot dog" , "pizza" , "donut" , "cake" , "chair" , "sofa" , "pottedplant" , "bed" , "diningtable" , "toilet" , "tvmonitor" , "laptop" , "mouse" , "remote" , "keyboard" , "cell phone" , "microwave" , "oven" , "toaster" , "sink" , "refrigerator" , "book" , "clock" , "vase" , "scissors" , "teddy bear" , "hair drier" , "toothbrush", "unidentified"};

//------------image coordinate struct-----------

struct XYZ{
	std::vector<float> x_lidar;
	std::vector<float> y_lidar;
	std::vector<float> z_lidar;
	std::vector<float> d_lidar;
	void reset() {
		x_lidar.clear();
		y_lidar.clear();
		z_lidar.clear();
		d_lidar.clear();
	}
};

struct IMGXY{
	std::vector<float> x_img ;
	std::vector<float> y_img ;

	void reset(){
		x_img.clear();
		y_img.clear();
	}
};


XYZ xyz;
//xyz.reset()

IMGXY img;
//img.reset();

//-------------lidar bbox points----------------
struct SegBox{
	std::vector<float> x;
	std::vector<float> y;
	std::vector<float> z;
	void reset(){
		x.clear();
		y.clear();
		z.clear();
	}
};

SegBox seg_box;


struct SegRect{
	std::vector<float> d_lidar;
	std::vector<float> x_rect_img;
	std::vector<float> y_rect_img;
	void reset(){
		d_lidar.clear();
		x_rect_img.clear();
		y_rect_img.clear();
	}
};

SegRect seg_rect;

//----------LIDAR Bbox points struct---------
struct LidarPt{
	std::vector<int> x ;
	std::vector<int> y ;
	std::vector<int> img_x ;
	std::vector<int> img_y ;
	std::vector<int> class_id ;
	void reset(){
		x.clear();
		y.clear();
		img_x.clear();
		img_y.clear();
		class_id.clear();
	}
};

LidarPt lidar_pt;

//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//------------------callback functions------------------
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


//------------calculate projection xyz from point cloud--------
void cloud_cb (const sensor_msgs::PointCloud2 msg){
	global_cloud.clear();
	//ros_pcl2 to pcl2
	pcl::PCLPointCloud2 pcl_pc;
	pcl_conversions::toPCL(msg, pcl_pc);

	pcl::PointCloud<PointXYZ> input_cloud;
	pcl::fromPCLPointCloud2(pcl_pc, input_cloud);
	
	global_cloud = input_cloud;
	
}

void image_cb (const sensor_msgs::ImageConstPtr& msg_ptr){

	cv_ptr = cv_bridge::toCvCopy(msg_ptr,"bgr8")  ;
}




//-----------subscribe the Bbox points-----------------------
void bbox_cb (const std_msgs::Int16MultiArray bboxmsg) {
	yolo_data.data.clear();
	yolo_bbox_n = bboxmsg.layout.dim.size();
	yolo_data = bboxmsg;

}

//-----------subscribe the tracking_objecsts points-------------
void tracking_cb (const tracking_msg::TrackingObjectArray trackmsg){
	seg_box.reset();
	lidar_data.array.clear();
	lidar_data = trackmsg;
	for(int i =0; i<trackmsg.array.size(); i++){
		for(int j=0; j<24; j++){
			seg_box.x.push_back(trackmsg.array[i].bbox.points[j].x);		
			seg_box.y.push_back(trackmsg.array[i].bbox.points[j].y);
			seg_box.z.push_back(trackmsg.array[i].bbox.points[j].z);
		}	
	}
}

//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//fusion 
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
int alignment(){

	//if there is no tracking data or velodyne points than return. 
	if( ((yolo_bbox_n == 0) && (lidar_data.array.size() == 0)) || (global_cloud.size() < 1) ){

		return 0;
	}
	//XYZ xyz;
	xyz.reset();

	//IMGXY img;
	img.reset();

	seg_rect.reset();
	
	lidar_pt.reset();

	std::vector<float> c ;


	//lidar point projection
	for(int i=0; i<global_cloud.size(); i++){

			xyz.x_lidar.push_back(global_cloud[i].x);
			xyz.y_lidar.push_back(global_cloud[i].y);
			xyz.z_lidar.push_back(global_cloud[i].z);
			//xyz.d_lidar.push_back(global_cloud[i].y);		

			xyz.d_lidar.push_back(sqrt(pow(global_cloud[i].x,2)+pow(global_cloud[i].y,2))); 
			img.x_img.push_back(round(atan2(-xyz.y_lidar[i],xyz.x_lidar[i])/h_res_rad - x_min - x_max/2 + w/2 )+15) ;
			//img.x_img.push_back(atan2(xyz.x_lidar[i] , sqrt(pow(xyz.y_lidar[i],2)+pow(xyz.z_lidar[i],2)))/h_res_rad + pi/2/h_res_rad);
			img.y_img.push_back(h-round(atan2(xyz.z_lidar[i],xyz.d_lidar[i])/v_res_rad - y_min)-60) ;

	}
	float min_values = *min_element(xyz.d_lidar.begin(),xyz.d_lidar.end()) ;
	float maX_values = *max_element(xyz.d_lidar.begin(),xyz.d_lidar.end()) ;
	
	for(int i=0; i<xyz.d_lidar.size(); i++){
		c.push_back((xyz.d_lidar[i]-min_values)/(maX_values-min_values));
	}
	for(int i=0; i<seg_box.x.size(); i++){
		seg_rect.d_lidar.push_back(sqrt(pow(seg_box.x[i],2)+pow(seg_box.y[i],2)));
		//calculate segmented box 8 points --> 2D projection points
		seg_rect.x_rect_img.push_back(atan2(-seg_box.y[i], seg_box.x[i])/h_res_rad - x_min);
		seg_rect.y_rect_img.push_back(atan2(seg_box.z[i], seg_rect.d_lidar[i])/v_res_rad - y_min);
	}

	for(int i=0; i<seg_rect.x_rect_img.size()/24; i++){
			float min_x = *min_element(seg_rect.x_rect_img.begin()+24*i, seg_rect.x_rect_img.begin()+24*i+24);
			float max_x = *max_element(seg_rect.x_rect_img.begin()+24*i, seg_rect.x_rect_img.begin()+24*i+24);
			float min_y = *min_element(seg_rect.y_rect_img.begin()+24*i, seg_rect.y_rect_img.begin()+24*i+24);
			float max_y = *max_element(seg_rect.y_rect_img.begin()+24*i, seg_rect.y_rect_img.begin()+24*i+24);
			lidar_pt.x.push_back(round(min_x)-x_max/2 + w/2+15) ;
			lidar_pt.y.push_back(round(h-max_y)-200) ;
			lidar_pt.x.push_back(round(max_x)-x_max/2+w/2+15) ;
			lidar_pt.y.push_back(round(h-min_y)-200) ;
			//std::cout<<"x1: "<<round(min_x)-x_max/2 + w/2<<"y1:"<<round(h-max_y)<<"x2:"<<round(max_x)-x_max/2+w/2<<"y2:"<<round(h-min_y)<<"\n";
			//rectangle(resizeImg, Point(round(min_x)-x_max/2 + w/2+13,round(h-max_y)-120), Point(round(max_x)-x_max/2+w/2, round(h-min_y)-120), Scalar(255,0,255),2) ;
	}

	float array[yolo_bbox_n][lidar_data.array.size()] ={0.0} ;
	std::vector<float> sumRow;
	std::vector<float> sumCol;

	//if there is more yolo_bbox than lidar tracking bbox
	for(int i=0; i<yolo_bbox_n; i++){
		IOU::Quad Qyolo(IOU::Point(yolo_data.data[8*i+3],yolo_data.data[8*i+4]), IOU::Point(yolo_data.data[8*i+5], yolo_data.data[8*i+4]), IOU::Point(yolo_data.data[8*i+5], yolo_data.data[8*i+6]), IOU::Point(yolo_data.data[8*i+3], yolo_data.data[8*i+6]));
		float sumrow=0;
		for(int j=0; j<lidar_data.array.size(); j++){
			IOU::Quad Qlidar(IOU::Point(lidar_pt.x[2*j],lidar_pt.y[2*j]), IOU::Point(lidar_pt.x[2*j+1], lidar_pt.y[2*j]), IOU::Point(lidar_pt.x[2*j+1],lidar_pt.y[2*j+1]), IOU::Point(lidar_pt.x[2*j], lidar_pt.y[2*j+1]));
			array[i][j]=IOU::iou(Qyolo, Qlidar);
			sumrow = sumrow + array[i][j];
		}
		sumRow.push_back(sumrow);	
	}

	for(int j=0; j<lidar_data.array.size(); j++){
		float sumcol=0;
		for(int i=0; i<yolo_bbox_n; i++){
			sumcol = sumcol + array[i][j];
		}
		sumCol.push_back(sumcol);
	}


	tracking_msg::TrackingObject msg_tracking_object;
	tracking_msg::TrackingObjectArray msg_tracking_object_array;

	std_msgs::Int32MultiArray bboxmsg;
	geometry_msgs::Point point;
	geometry_msgs::Point velocity;
	int tracking_size =0 ;
	if(yolo_bbox_n != 0){
		for(int i=0; i<yolo_bbox_n; i++){
			
			float d = yolo_data.data[8*i+7];

			// case1 : only yolo tracking
			if(sumRow[i] == 0){
				//name 
				msg_tracking_object.name.data = "V";

				//bbox2d
				bboxmsg.data.push_back(yolo_data.data[8*i+3]);	//x
				bboxmsg.data.push_back(yolo_data.data[8*i+4]);	//y
				bboxmsg.data.push_back(yolo_data.data[8*i+5]);	//x
				bboxmsg.data.push_back(yolo_data.data[8*i+6]);	//y

				msg_tracking_object.bbox2d = bboxmsg;
				
				std::vector<float> dist;

				//bev
				//calculate bev 

				for(int p=0 ; p<2; p++){

					float bevx = (d * fabs(cos(h_res_rad*(bboxmsg.data[2*p]+x_min+x_max/2-w/2-15))) )  ;
					float bevy = bevx * tan(h_res_rad*(bboxmsg.data[2*p] + x_min + x_max/2 -w/2 -15)) ;
						
					msg_tracking_object.bev.data.push_back(bevx) ; 
					msg_tracking_object.bev.data.push_back(bevy) ; 
				}			
				bboxmsg.data.clear();
				std::vector<float> pt;
				//point
				for(int k=0; k<img.x_img.size(); k++){
					if((img.x_img[k]>yolo_data.data[8*i+3]) &&
						(img.x_img[k]<yolo_data.data[8*i+5]) &&
						(img.y_img[k]>yolo_data.data[8*i+4]) &&
						(img.y_img[k]<yolo_data.data[8*i+6])){
						dist.push_back(xyz.d_lidar[k]);
						pt.push_back(xyz.x_lidar[k]);
						pt.push_back(xyz.y_lidar[k]);
						pt.push_back(xyz.z_lidar[k]);
					}
				}

				if(dist.size() > 0){
					float mindistance = *min_element(dist.begin(), dist.end());
					int minElementIndex = std::min_element(dist.begin(),dist.end()) - dist.begin();

					if( mindistance  <= yolo_data.data[8*i+7]){
						msg_tracking_object.distance.data = yolo_data.data[8*i+7];}
					else{
						msg_tracking_object.distance.data = mindistance;
						msg_tracking_object.point.x=pt[3*minElementIndex]; 
						msg_tracking_object.point.y=pt[3*minElementIndex];
						msg_tracking_object.point.z=pt[3*minElementIndex];  }
	 
					dist.clear();
					pt.clear();
				}
				else{
					msg_tracking_object.distance.data = yolo_data.data[8*i+7];
					float imgx = (yolo_data.data[8*i+3] + yolo_data.data[8*i+5]) /2 ;
					float imgy = (yolo_data.data[8*i+4] + yolo_data.data[8*i+6]) /2 ;
	 				float pointx =  (d * fabs(cos(h_res_rad*(imgx+x_min+x_max/2-w/2-15))) ) ;
					float pointy = pointx * tan(h_res_rad*(imgx + x_min + x_max/2 -w/2 -15)) ;
					float pointz = d * tan(v_res_rad *(h-imgy-y_min-60))  ;
					msg_tracking_object.point.x = pointx;
					msg_tracking_object.point.y = pointy;
					msg_tracking_object.point.z = pointz;		
				}
				//velocity : there is no velocity matched in yolobbox.
				msg_tracking_object.velocity.x = 1000;
				msg_tracking_object.velocity.y = 1000;
				msg_tracking_object.velocity.z = 1000;
				
				//state
				msg_tracking_object.state = -1 ;

				//type_id
				msg_tracking_object.type_id = yolo_data.data[8*i];

				//ttc
				msg_tracking_object.ttc = 1000;

				msg_tracking_object_array.array.push_back(msg_tracking_object);
				msg_tracking_object.bbox2d.data.clear();
				tracking_size = tracking_size + 1 ;
				}
			else{
				for(int j=0; j<lidar_data.array.size(); j++){
					// case2 : lidar & camera tracking 
					if( *max_element(array[i], array[i]+(lidar_data.array.size()-i+1)) == array[i][j] ){
						//id
						msg_tracking_object.id = lidar_data.array[j].id ;

						//name
						msg_tracking_object.name.data = "VL" ;

						//bbox2d
						bboxmsg.data.push_back(lidar_pt.x[2*j]);
						bboxmsg.data.push_back(lidar_pt.y[2*j]);
						bboxmsg.data.push_back(lidar_pt.x[2*j+1]);
						bboxmsg.data.push_back(lidar_pt.y[2*j+1]);

						msg_tracking_object.bbox2d = bboxmsg;
						bboxmsg.data.clear();
						
						//bev
						msg_tracking_object.bev = lidar_data.array[j].bev ;

						//point
						msg_tracking_object.point = lidar_data.array[j].point ;
						
						//distance
						msg_tracking_object.distance.data = sqrt(pow(lidar_data.array[j].point.x,2)+pow(lidar_data.array[j].point.y,2));

						//velocity
						msg_tracking_object.velocity = lidar_data.array[j].velocity;

						//state
						msg_tracking_object.state = lidar_data.array[j].state;

						//type_id
						msg_tracking_object.type_id = yolo_data.data[8*i] ; 

						//ttc 
						msg_tracking_object.ttc = lidar_data.array[j].ttc;
						msg_tracking_object_array.array.push_back(msg_tracking_object);
						msg_tracking_object.bbox2d.data.clear();
						tracking_size = tracking_size + 1 ;

					}	
					// case3 : only lidar tracking
					else{
						
						//id
						msg_tracking_object.id = lidar_data.array[j].id ;

						//name
						msg_tracking_object.name.data = "L" ;

						
						//bbox2d
						bboxmsg.data.push_back(lidar_pt.x[2*j]);
						bboxmsg.data.push_back(lidar_pt.y[2*j]);
						bboxmsg.data.push_back(lidar_pt.x[2*j+1]);
						bboxmsg.data.push_back(lidar_pt.y[2*j+1]);

						msg_tracking_object.bbox2d = bboxmsg;
						bboxmsg.data.clear();

						//bev 
						msg_tracking_object.bev = lidar_data.array[j].bev;

						//point
						msg_tracking_object.point = lidar_data.array[j].point ;

						//distance 
						msg_tracking_object.distance.data = sqrt(pow(lidar_data.array[j].point.x,2)+pow(lidar_data.array[j].point.y,2));

						//velocity
						msg_tracking_object.velocity = lidar_data.array[j].velocity;

						//state
						msg_tracking_object.state = lidar_data.array[j].state;

						//type_id
						msg_tracking_object.type_id = COCO_CLASSES_LIST.size();

						//ttc
						msg_tracking_object.ttc = lidar_data.array[j].ttc;
						msg_tracking_object_array.array.push_back(msg_tracking_object);
						msg_tracking_object.bbox2d.data.clear();
						tracking_size = tracking_size + 1 ;

					}

				}
			}

		}

		msg_tracking_object_array.car_velocity = lidar_data.car_velocity;
		msg_tracking_object_array.size = tracking_size;

		pub.publish(msg_tracking_object_array);


		//Mat resizeImg(h,w , CV_8UC3) ;

		//resize(cv_ptr->image, resizeImg, Size(w,h));

		//for(int i=0; i<img.x_img.size(); i++){
		//	circle(resizeImg, Point(round(img.x_img[i]) , round(img.y_img[i])), 1.5, Scalar( round((abs(6*c[i]-3)-1)*255), round((2-abs(6*c[i]-2))*255), round((2-abs(6*c[i]-4))*255) ), -1);

		//}

		//for(int j= 0; j<lidar_pt.x.size()/2; j++ ){
		//	rectangle(resizeImg, Point(lidar_pt.x[2*j], lidar_pt.y[2*j]), Point(lidar_pt.x[2*j+1], lidar_pt.y[2*j+1]),Scalar(255,0,255), 2) ;
			//putText(resizeImg,COCO_CLASSES_LIST[lidar_pt.class_id[j]], Point(lidar_pt.x[2*j], lidar_pt.y[2*j]-6), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(255,0,255),1) ;

		//}
		//for(int i=0; i<msg_tracking_object_array.size; i++){
		//	rectangle(resizeImg, Point(msg_tracking_object_array.array[i].bbox2d.data[0], msg_tracking_object_array.array[i].bbox2d.data[1]), Point(msg_tracking_object_array.array[i].bbox2d.data[2], msg_tracking_object_array.array[i].bbox2d.data[3]),Scalar(255,0,255), 2) ;}
		//resize(resizeImg, resizeImg, Size(w/3,h/3));
		//imshow("result", resizeImg);
		//waitKey(1);
		msg_tracking_object_array.array.clear();
	}
	else if(yolo_bbox_n == 0){

		for(int j=0; j<lidar_data.array.size(); j++){
			//id
			msg_tracking_object.id = lidar_data.array[j].id ;

			//name
			msg_tracking_object.name.data = "L" ;

			
			//bbox2d
			bboxmsg.data.push_back(lidar_pt.x[2*j]);
			bboxmsg.data.push_back(lidar_pt.y[2*j]);
			bboxmsg.data.push_back(lidar_pt.x[2*j+1]);
			bboxmsg.data.push_back(lidar_pt.y[2*j+1]);

			msg_tracking_object.bbox2d = bboxmsg;
			bboxmsg.data.clear();

			//bev 
			msg_tracking_object.bev = lidar_data.array[j].bev;

			//point
			msg_tracking_object.point = lidar_data.array[j].point ;

			//distance 
			msg_tracking_object.distance.data = sqrt(pow(lidar_data.array[j].point.x,2)+pow(lidar_data.array[j].point.y,2));

			//velocity
			msg_tracking_object.velocity = lidar_data.array[j].velocity;

			//state
			msg_tracking_object.state = lidar_data.array[j].state;

			//type_id
			msg_tracking_object.type_id = COCO_CLASSES_LIST.size();

			//ttc
			msg_tracking_object.ttc = lidar_data.array[j].ttc;
			msg_tracking_object_array.array.push_back(msg_tracking_object);
			msg_tracking_object.bbox2d.data.clear();

			tracking_size += 1;
		}
	
		msg_tracking_object_array.car_velocity = lidar_data.car_velocity;
		msg_tracking_object_array.size = tracking_size;

		pub.publish(msg_tracking_object_array);
		msg_tracking_object_array.array.clear();
	}


	return 0;
}


int main(int argc, char** argv){

	//initialize ROS
	ros::init (argc, argv, "fusion_car_tracking");
	ros::Time::init();
	ros::Rate r(1);
	ros::NodeHandle nh;

	//ros::AsyncSpinner spiner(1);
	cv_ptr.reset();
	ros::Subscriber imagesub = nh.subscribe ("/image",0,image_cb);
	//Create a Ros subscriber for the input point cloud 
	ros::Subscriber lidarsub = nh.subscribe ("/velodyne_points",0,cloud_cb);
	//ros::Subscriber Bboxsub = nh.subscribe ("/TRT_yolov3/Bbox", 0, bbox_cb);
	ros::Subscriber trackingsub = nh.subscribe("/lidar/tracking_objects", 0, tracking_cb);
	ros::Subscriber cartracksub = nh.subscribe("/tracking/car", 0,bbox_cb);

	pub = nh.advertise<tracking_msg::TrackingObjectArray>("/fusion/lidar_camera", 0);

    //spiner.start();
    //ROS_INFO("alignment started...");

    //ros::waitForShutdown();
    //ROS_INFO("alignment exited...");
	while(ros::ok()){

		//Fuck!
		alignment();
		
		ros::spinOnce();
	}


}
